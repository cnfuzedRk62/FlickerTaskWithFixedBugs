//  BottomCell.swift
//  App411
//
//  Created by Mandeep Singh on 09/09/18.
//  Copyright © 2018 osvinuser. All rights reserved.

import UIKit

class BottomCell: UICollectionViewCell {

    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
