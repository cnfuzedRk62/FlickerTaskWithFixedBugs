//  AUserInfoModel.swift
//  App411
//  Created by osvinuser on 6/28/17.
//  Copyright © 2017 osvinuser. All rights reserved.

import Foundation
import ObjectMapper

class PhotosModel: Mappable {
    
    var photoId: String?
    var farm: Int?
    var secret: String?
    var server: String?
    var title: String?
    
    required init?(map: Map) {
        mapping(map: map)
    }
    
    //Mappable
    open func mapping(map: Map) {
        
        photoId     <- map["photoId"]
        farm        <- map["farm"]
        secret      <- map["secret"]
        server      <- map["server"]
        title       <- map["title"]
       
    }
  
}

