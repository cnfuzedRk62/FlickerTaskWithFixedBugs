//
//  ViewController.swift
//  FlickerAPiTask
//
//  Created by Ravinder on 04/09/19.
//  Copyright © 2019 Ravinder. All rights reserved.
//

import UIKit
import SDWebImage
import ObjectMapper
class ViewController: UIViewController {
    @IBOutlet var collectionView: UICollectionView!
    let searchBar = UISearchBar()
    var selectedRows = 2
    var selectedHeight = 3
    var post_Count = 1
    var refreshControlBottom = UIRefreshControl()
    var photos: [FlickrPhoto] = []
    var currentPageValue = 0
    var refreshControl: UIRefreshControl!
    var isLoadingMore = false
  //  var photosModel = [PhotosModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        searchBar.sizeToFit()
        searchBar.delegate = self
        searchBar.placeholder = "Search Images"
        self.navigationController?.navigationBar.topItem?.titleView = searchBar
        let logoutBarButtonItem = UIBarButtonItem(title: "Options", style: .done, target: self, action: #selector(options))
        self.navigationItem.rightBarButtonItem  = logoutBarButtonItem
        self.registerXib()
    }
    
    func registerXib(){
         self.collectionView.register(UINib(nibName: "BottomCell", bundle: Bundle.main), forCellWithReuseIdentifier: "BottomCell")
         collectionView!.register(UINib(nibName: "ImageCollectionViewCell", bundle: Bundle.main), forCellWithReuseIdentifier: "ImageCollectionViewCell")
    }
    
    // MARK: - refresh control For API
    func refreshControlAPI() {
        refreshControl = UIRefreshControl()
        refreshControl.tintColor = UIColor.lightGray
        refreshControl.addTarget(self, action: #selector(self.reloadAPI), for: .valueChanged)
        self.collectionView.addSubview(refreshControl) // not required when using UITableViewController
        self.reloadAPI()
    }
    
    //MARK:- Reload API
    @objc func reloadAPI() {
        print("yes")
        //First time automatically refreshing.
        //check net connection
        if Reachability.isConnectedToNetwork() == true {
           // self.getFollowerRequestList(count: String(post_Count))
            
        } else {
            // Refresh end.
          //  self.setupEmptyView()
          //  self.showNetworkAndRefreshView(messageString: AKErrorHandler.CommonErrorMessages.NO_INTERNET_AVAILABLE)
        }
    }
    
    func reloadAPIByCount() {
        print("No")
       
        if searchBar.text?.count ?? 0 > 0 {
             self.post_Count += 1
             self.performSearchWithText(searchText: searchBar.text!, pageCount: post_Count)
        }else{
             self.post_Count = 1
            self.collectionView.reloadData()
        }
    
    }
    
    @objc func options(){
        let alert = UIAlertController(title: "Poplify Demo", message: "Please Select an Option", preferredStyle: .actionSheet)
        
        alert.addAction(UIAlertAction(title: "2 Rows", style: .default , handler:{ (UIAlertAction)in
            print("User click Approve button")
            self.selectedRows = 2
            self.selectedHeight = 3
            self.collectionView.reloadData()
        }))
        
        alert.addAction(UIAlertAction(title: "3 Rows", style: .default , handler:{ (UIAlertAction)in
            print("User click Edit button")
            self.selectedRows = 3
            self.selectedHeight = 6
            self.collectionView.reloadData()
        }))
        
        alert.addAction(UIAlertAction(title: "4 Rows", style: .default , handler:{ (UIAlertAction)in
            print("User click Delete button")
            self.selectedRows = 4
            self.selectedHeight = 8
            self.collectionView.reloadData()
        }))
        
        alert.addAction(UIAlertAction(title: "Dismiss", style: .cancel, handler:{ (UIAlertAction)in
            print("User click Dismiss button")
        }))
        
        self.present(alert, animated: true, completion: {
            print("completion block")
        })
    }

}

//MARK:- UICOLLECTION VIEW METHODS

extension ViewController : UICollectionViewDelegate, UICollectionViewDataSource ,UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        //return photos.count
        if self.searchBar.text?.count ?? 0 > 0 {
            return photos.count >= 20 ? photos.count + 1 : photos.count
        }else{
           return photos.count
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if indexPath.item == self.photos.count {
            return self.loaderCell(indexPath: indexPath)
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ImageCollectionViewCell", for: indexPath) as! ImageCollectionViewCell
               cell.imageView.sd_setImage(with: photos[indexPath.row].photoUrl as URL, placeholderImage: #imageLiteral(resourceName: "placeholder"))
            return cell
        }
    }
 
    private func loaderCell(indexPath: IndexPath) -> UICollectionViewCell {
        let cell = self.collectionView.dequeueReusableCell(withReuseIdentifier: "BottomCell", for: indexPath) as! BottomCell
            cell.activityIndicator.startAnimating()
            return cell
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        self.detectScroll(scroll: scrollView)
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        self.detectScroll(scroll: scrollView)
    }
    
    func detectScroll(scroll: UIScrollView) {
        
        if self.updateCollectionScrollViewFunction() && self.bottomServiceCall() {
            self.reloadAPIByCount()
        }
    }
    
    func updateCollectionScrollViewFunction() -> Bool {
        let contentOffset = self.collectionView.contentOffset.y //50
        let contentHeight = self.collectionView.contentSize.height //6000
        let diffHeight = contentHeight - contentOffset; // 1200
        let frameHeight = self.view.bounds.size.height; // 700
        return (frameHeight * 1.2) > diffHeight ? true : false
    }
    
    func bottomServiceCall() -> Bool {
        
        if self.isLoadingMore == false && self.currentPageValue >= 19 && self.photos.count <= 500 {
            if Reachability.isConnectedToNetwork() == true {
                self.isLoadingMore = true
                return true
            }
        }
        return false
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if indexPath.item == self.photos.count {
            if self.searchBar.text?.count ?? 0 > 0 {
                return CGSize(width: self.view.frame.size.width, height: 150)
            } else {
                return CGSize(width: self.view.frame.size.width, height: 0)
            }
        } else {
            var collectionViewSize = collectionView.frame.size
            let prefferedWidth = ((view.bounds.width - CGFloat((selectedRows) * 8))) //for 2 row edit or whatever row you want
            let mainWidth = prefferedWidth/CGFloat(selectedRows)
            collectionViewSize.width = mainWidth//Display Three elements in a row.
            let innerMethod = (view.bounds.height - CGFloat(4 * 8))
            collectionViewSize.height = innerMethod/CGFloat(selectedHeight)  //collectionViewSize.height/4.0
            return collectionViewSize
        }
      
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 10.0
    }
    
  // Flicker Api
    private func performSearchWithText(searchText: String , pageCount : Int) {
        var count = pageCount
        if searchText != self.searchBar.text ?? "" {
            count = 1
        }
        
        FlickrProvider.fetchPhotosForSearchText(searchText: searchText, page: count, onCompletion: { (error: NSError?, flickrPhotos: [FlickrPhoto]?) -> Void in
            if error == nil {
                
                DispatchQueue.main.async(execute: {
                    if let searchBarText = self.searchBar.text, searchBarText == searchText, count != 1 {
                        self.photos += flickrPhotos!
                    } else {
                        self.photos = flickrPhotos!
                    }
                    self.currentPageValue = flickrPhotos!.count
                    self.isLoadingMore = false
                })
           } else {
                self.photos = []
                print("New error\(error?.localizedDescription)")
                if (error!.code == FlickrProvider.Errors.invalidAccessErrorCode) {
                    DispatchQueue.main.async(execute: { () -> Void in
                       // self.showErrorAlert()
                    })
                }
            }
            DispatchQueue.main.async(execute: { () -> Void in
                self.title = searchText
                self.collectionView.delegate = self
                self.collectionView.dataSource = self
                self.collectionView.reloadData()
            })
        })
    }
 
    private func showErrorAlert() {
        let alertController = UIAlertController(title: "Search Error", message: "Invalid API Key", preferredStyle: .alert)
        let dismissAction = UIAlertAction(title: "Dismiss", style: .default, handler: nil)
        alertController.addAction(dismissAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        performSearchWithText(searchText: searchBar.text!, pageCount: post_Count)
    }

 
}

extension ViewController : UISearchControllerDelegate, UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if Reachability.isConnectedToNetwork() == true {
            print("Hello\(searchBar.text!)")
            //let trimmedString = searchBar.trimmingCharacters(in: .whitespaces)
            let trimmedChar = searchBar.text?.trimmingCharacters(in: .whitespaces)
            if trimmedChar?.count ?? 0 > 0 {
                    performSearchWithText(searchText: searchBar.text!, pageCount: post_Count)
            }
        } else {
            let alertController = UIAlertController(title: "Internet Error", message: "Check your internetConnection.", preferredStyle: .alert)
            let dismissAction = UIAlertAction(title: "Dismiss", style: .default, handler: nil)
            alertController.addAction(dismissAction)
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
    
}


extension UIScrollView {
    
    func updateScrollViewFunction() -> Bool {
        let contentOffset = self.contentOffset.y; //50
        let contentHeight = self.contentSize.height; //6000
        let diffHeight = contentHeight - contentOffset; // 1200
        let frameHeight = self.bounds.size.height; // 700
        return (frameHeight * 2.0) > diffHeight ? true : false
    }
}
